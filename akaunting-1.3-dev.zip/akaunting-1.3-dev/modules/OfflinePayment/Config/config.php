<?php

return [

    'name' => 'OfflinePayment',

];
