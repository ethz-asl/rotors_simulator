<?php

return [

    'name' => 'PaypalStandard',

];
